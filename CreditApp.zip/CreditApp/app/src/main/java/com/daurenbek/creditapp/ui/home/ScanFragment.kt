package com.daurenbek.creditapp.ui.home

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import com.daurenbek.creditapp.R
import com.daurenbek.creditapp.databinding.FragmentScanBinding
import kotlinx.coroutines.Job

class ScanFragment : Fragment(R.layout.fragment_scan) {
    private lateinit var binding: FragmentScanBinding

/*    private val viewModel by viewModels<HomeViewModel> {
        HomeViewModelFactory(
            ResourceHelper(
                requireContext()
            )
        )
    }*/

    private var pauseJob: Job? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentScanBinding.bind(view)

        Log.d("Infostart", "loaded scanFragment")

        val qrScannerFragment = QrScannerFragment()
        childFragmentManager.beginTransaction().apply {
            add(R.id.child_fragment_container, qrScannerFragment)
            commit()
        }


    }


}