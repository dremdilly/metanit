package com.daurenbek.creditapp.ui.home

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import com.daurenbek.creditapp.R
import com.daurenbek.creditapp.databinding.FragmentProductBinding
import kotlinx.coroutines.Job

class ProductFragment:Fragment(R.layout.fragment_product) {
    private lateinit var binding: FragmentProductBinding

    private var pauseJob: Job? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentProductBinding.bind(view)

        Log.d("Infostart", "loaded scanFragment")

        binding.credit1Btn.setOnClickListener{
            var dialog = CustomDialogFragment()

            dialog.show(requireFragmentManager(), "customDialog")
        }
    }

}