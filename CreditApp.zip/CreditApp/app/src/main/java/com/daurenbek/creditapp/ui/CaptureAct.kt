package com.daurenbek.creditapp.ui

import com.journeyapps.barcodescanner.CaptureActivity

class CaptureAct : CaptureActivity() {
}