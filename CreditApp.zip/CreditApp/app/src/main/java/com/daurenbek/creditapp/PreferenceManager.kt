package com.daurenbek.creditapp

import android.content.Context
import androidx.datastore.DataStore
import androidx.datastore.preferences.Preferences
import androidx.datastore.preferences.createDataStore
import kotlinx.coroutines.flow.Flow

object PreferenceManager {
    private const val TAG = "PreferenceManager"

    lateinit var dataStore: DataStore<Preferences>
    lateinit var preferenceFlow: Flow<Preferences>

    fun initPreferences(context: Context) {
        dataStore = context.createDataStore("user_preferences")
        preferenceFlow = dataStore.data
    }
}