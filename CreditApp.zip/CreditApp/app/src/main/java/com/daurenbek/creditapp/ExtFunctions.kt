package com.daurenbek.creditapp

import androidx.core.text.isDigitsOnly
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import java.time.YearMonth

fun isValidIin(iin: String): Boolean {
    if (12 == iin.length && iin.isDigitsOnly()) {
        var year: String = ""
        for (i in iin.indices) {
            if(i == 0 || i == 1) {
                if(iin[i].isDigit())
                    continue;
                else
                    return false;
            } else if(i == 2) {
                if (iin[i] == '0' || (iin[i] == '1' && (iin[3] == '1' || iin[3] == '2' || iin[3] == '0'))) {
                    continue;
                } else
                    return false;
            } else if(i == 4) {
                year += if(iin[0] == '0' || iin[0] == '1' || iin[0] == '2') {
                    "20" + iin[0] + iin[1]
                } else {
                    "19" + iin[0] + iin[1]
                }
                val month: String = "" + iin[2] + iin[3]
                val day: String = "" + iin[i] + iin[5]
                val date: YearMonth = YearMonth.of(year.toInt(), month.toInt())
                if(date.isValidDay(day.toInt()))
                    continue
                else
                    return false
            } else if(i == 6) {
                if(iin[i] == '1' || iin[i] == '2' || iin[i] == '3' || iin[i] == '4' || iin[i] == '5' || iin[i] == '6')
                    continue
                else
                    return false
            } else if(i == 7 || i == 8 || i == 9 || i == 10) {
                if(iin[i].isDigit())
                    continue
                else
                    return false
            } else if(i == 11) {
                var sum: Int = (iin[0].toInt()*1 + iin[1].toInt()*2  + iin[2].toInt()*3 + iin[3].toInt()*4 + iin[4].toInt()*5 + iin[5].toInt()*6 + iin[6].toInt()*7 +
                        iin[7].toInt()*8 + iin[8].toInt()*9 + iin[9].toInt()*10 + iin[10].toInt()*11) % 11
                return if(sum == 10) {
                    sum = (iin[0].toInt()*3 + iin[1].toInt()*4  + iin[2].toInt()*5 + iin[3].toInt()*6 + iin[4].toInt()*7 + iin[5].toInt()*8 + iin[6].toInt()*9 +
                            iin[7].toInt()*10 + iin[8].toInt()*11 + iin[9].toInt()*1 + iin[10].toInt()*2) % 11
                    sum != 10
                } else {
                    true
                }
            }
        }
    }

    return false;
}

fun Fragment.showSnackbar(msg: String) {
    Snackbar.make(requireView(), msg, Snackbar.LENGTH_SHORT).show()
}