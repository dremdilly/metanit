package com.daurenbek.creditapp.ui.init

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.daurenbek.creditapp.R
import com.daurenbek.creditapp.databinding.FragmentPhoneBinding

class PhoneFragment : Fragment(R.layout.fragment_phone) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val binding = FragmentPhoneBinding.bind(view)

        binding.continueBtn.setOnClickListener {
            val action = PhoneFragmentDirections.actionPhoneFragmentToSignInSmsFragment()
            findNavController().navigate(action)
        }

        Log.d("Infostart", "loaded phonefragment")

    }
}