package com.daurenbek.creditapp

object Consts {

    const val VIBRATION_DURATION_SUCCESS = 200L
    const val VIBRATION_DURATION_ERROR = 700L
    const val VIBRATION_DURATION_WARNING = 500L

    const val DELAY_TIME_FOR_REPLAY = 5000L
}