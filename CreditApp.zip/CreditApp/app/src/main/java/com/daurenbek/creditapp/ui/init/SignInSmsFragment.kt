package com.daurenbek.creditapp.ui.init

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.daurenbek.creditapp.R
import com.daurenbek.creditapp.databinding.FragmentSigninSmsBinding

class SignInSmsFragment : Fragment(R.layout.fragment_signin_sms) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val binding = FragmentSigninSmsBinding.bind(view)

        binding.continueBtn.setOnClickListener {
            val action = SignInSmsFragmentDirections.actionSignInSmsFragmentToScanFragment()
            findNavController().navigate(action)
        }

        Log.d("Infostart", "loaded signInSmsFragment")
    }
}