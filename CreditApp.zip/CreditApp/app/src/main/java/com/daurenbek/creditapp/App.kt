package com.daurenbek.creditapp

import android.app.Application
import com.google.zxing.client.android.BuildConfig
import timber.log.Timber

/**
 * Created by daurenbek on 16.10.2021.
 * email: drenbek@gmail.com
 */

class App : Application() {

    override fun onCreate() {
        super.onCreate()

        PreferenceManager.initPreferences(applicationContext)

        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
    }
}